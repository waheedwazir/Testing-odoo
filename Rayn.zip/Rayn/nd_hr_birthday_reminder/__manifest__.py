{
    "name": "Birthday Wish & Reminder",
    "version": "15.0.0.1.0",
    "category": "Human Resources",
    "summary": "Employee Birthday Wish & Reminder",
    "description": """
        Send email Birthday Wish to Employee
        Send email Reminder To Manager for Birthday Wish
    """,
    "author": "NumDesk",
    "website": "https://numdesk.com",
    "depends": ["hr"],
    "license": "OPL-1",
    "data": [
        "data/birthday_reminder_cron.xml",
        "data/mail_templates.xml",
        "data/ir_config_settings_data.xml",
        "views/res_config_settings_views.xml",
    ],
    "images": ["static/description/heliconia_birthday_reminder_wish.gif"],
    "installable": True,
    "auto_install": False,
    "application": True,
}
