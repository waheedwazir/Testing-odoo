# -*- coding: utf-8 -*-

{
    "name": "Enhancement In Payment Mechanism",
    "summary": "",
    "version": "1.5",
    "license": "",
    "category": "",
    "depends": [
        "account",
        "account_check_printing"
    ],
    "data": [
        "wizard/invoice_batch_process_view.xml",
        "views/account_tax_view.xml",
        "views/account_payment_view.xml",
        "security/ir.model.access.csv"
    ],
    "installable": True,
}
